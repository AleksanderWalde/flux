<?php

// Language definitions used in viewtopic.php
$lang_topic = array(

'Post reply'		=>	'Post reply',
'Topic closed'		=>	'Topic closed',
'From'				=>	'From:', // User location
'Promote user'		=>	'Promote user',
'IP address logged'	=>	'IP address logged',
'Note'				=>	'Note:', // Admin note
'Posts'				=>	'Posts:',
'Registered'		=>	'Registered:',
'Replies'			=>	'Replies:',
'Website'			=>	'Website',
'Guest'				=>	'Guest',
'Online'			=>	'Online',
'Offline'			=>	'Offline',
'Last edit'			=>	'Last edited by',
'Report'			=>	'Report',
'Delete'			=>	'Delete',
'Edit'				=>	'Edit',
'Quote'				=>	'Quote',
'Is subscribed'		=>	'You are currently subscribed to this topic',
'Unsubscribe'		=>	'Unsubscribe',
'Subscribe'			=>	'Subscribe to this topic',
'Quick post'		=>	'Quick reply',
'Mod controls'		=>	'Moderator controls',
'New icon'			=>	'New post',
'Re'				=>	'Re:',
'Preview'			=>	'Preview'

);
